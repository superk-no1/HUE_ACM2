package club.superk.hueacm.backend.service.user.account;

import club.superk.hueacm.backend.result.Result;

import java.util.Map;

public interface UpdateUserService {

    Result<Void> updateUserInfo(Map<String, String> data);

}
