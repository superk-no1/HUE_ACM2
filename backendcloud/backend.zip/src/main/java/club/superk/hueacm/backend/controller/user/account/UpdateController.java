package club.superk.hueacm.backend.controller.user.account;

import club.superk.hueacm.backend.result.Result;
import club.superk.hueacm.backend.service.user.account.UpdateUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/user/account")
public class UpdateController {

    @Autowired
    private UpdateUserService updateUserService;

    @PostMapping("/update")
    public Result<Void> updateUser(@RequestParam Map<String, String> data) {
        return updateUserService.updateUserInfo(data);
    }

}
