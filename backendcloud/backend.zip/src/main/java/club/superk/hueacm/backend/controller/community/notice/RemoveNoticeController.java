package club.superk.hueacm.backend.controller.community.notice;

public class RemoveNoticeController {
}
