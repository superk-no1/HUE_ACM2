package club.superk.hueacm.backend.controller.community.article;

public class RemoveArticleController {
}
