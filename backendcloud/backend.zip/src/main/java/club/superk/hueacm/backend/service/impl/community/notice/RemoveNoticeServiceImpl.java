package club.superk.hueacm.backend.service.impl.community.notice;

public class RemoveNoticeServiceImpl {
}
