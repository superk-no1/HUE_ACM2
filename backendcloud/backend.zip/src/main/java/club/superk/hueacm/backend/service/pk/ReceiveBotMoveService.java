package club.superk.hueacm.backend.service.pk;

public interface ReceiveBotMoveService {
    String receiveBotMove(Integer userId, Integer direction);
}
